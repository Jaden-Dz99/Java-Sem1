import javax.swing.*;
public class CreateJFrameWithComponents
{
   public static void main(String[] args)
   {
      JFrameWithComponents aFrame = new JFrameWithComponents();
      final int HEIGHT = 100;
      final int WIDTH = 350;
      aFrame.setSize(WIDTH, HEIGHT);
      aFrame.setVisible(true);
   }
}