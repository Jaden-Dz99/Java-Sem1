

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JOptionPane;

public class JBookQuote2 {

    public static void main(String[] args) {
    
      final int FRAME_WIDTH = 400;
      final int FRAME_HEIGHT = 100;
     

        final JFrame frame = new JFrame("Show Quotes");
      frame.setSize(FRAME_WIDTH, FRAME_HEIGHT);
      frame.setVisible(true);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        
        JPanel panel = new JPanel();

        JButton button1 = new JButton("How to ged rid of being Human");

        frame.add(panel);
        panel.add(button1);
        frame.setVisible(true);

        button1.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent arg0) {
                JOptionPane.showMessageDialog(frame.getComponent(0), "Belive in Vegan");

            }
        });
        
        JPanel panel2 = new JPanel();

        JButton button2 = new JButton("Can I be a Superman?");
        
        frame.add(panel);
        panel.add(button2);
        frame.setVisible(true);

        button2.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent arg0) {
                JOptionPane.showMessageDialog(frame.getComponent(0), "Yes you can");

            }
        });


    }

}