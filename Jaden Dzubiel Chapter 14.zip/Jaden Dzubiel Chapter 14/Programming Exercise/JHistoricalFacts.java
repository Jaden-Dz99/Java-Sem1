import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class JHistoricalFacts extends JFrame implements ActionListener
{
   FlowLayout flow = new FlowLayout();
   JButton b = new JButton("The Facts That");
   JLabel stars = new JLabel("--------------------------------------------->");//Create an application with a JFrame 
   JLabel f1 = new JLabel("1.)In 1838 it was declared illegal to swim at public beaches during the day!   ");//Add at least five labels
   JLabel f2 = new JLabel("2.)Female vote - Australia was the second country to give women the vote.                    ");
   JLabel f3 = new JLabel("3.)Until 1984, Australia's National anthem was 'God save the Queen/King.'");
   JLabel f4 = new JLabel("4.)Australia day, is the anniversary of ships arriving in Sydney carrying a load of Convicts.              ");
   JLabel f5 = new JLabel("5.)Australia was the 3rd country, after the US and Russia, to launch a satellite into orbit.");
   int counter = 0;//Add Counter Valuable
   public JHistoricalFacts()
   {
      super("The Unusual Asutralian Facts You Would Know");
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//Close Fram When User Click Close Button
      setLayout(flow);
      add(b);//Add Button
      add(stars);//Add Sub Headline
      add(f1);//Add First Label
      b.addActionListener(this);
   }
   public static void main(String[] args)
   {
      JHistoricalFacts rFrame = new JHistoricalFacts();//Adframe
      rFrame.setSize(600,200);//Manage Frame Size
      rFrame.setVisible(true);
   }
   @Override
   public void actionPerformed(ActionEvent e)
   {
      ++counter;
      if(counter == 5)
        counter = 0;
      if(counter == 1)  //Every time the user clicks a JButton, remove one of the labels and add a different one.
      {
          remove(f1);
          add(f2);
      }
      else
         if(counter == 2)//Every time the user clicks a JButton, remove one of the labels and add a different one.
         {
             remove(f2);
             add(f3);
         }
         else
             if(counter == 3)//Every time the user clicks a JButton, remove one of the labels and add a different one.
             {
                  remove(f3);
                  add(f4);
             }
             else
                if(counter == 4)//Every time the user clicks a JButton, remove one of the labels and add a different one.
                {
                   remove(f4);
                   add(f5);
                }
                else
                {
                    remove(f5);//Every time the user clicks a JButton, remove one of the labels and add a different one.
                    add(f1);
                }
                   
      validate();
      repaint();
  }

}