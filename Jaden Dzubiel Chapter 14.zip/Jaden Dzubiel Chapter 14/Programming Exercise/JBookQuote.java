import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class JBookQuote extends JFrame
{

   FlowLayout flow = new FlowLayout();
   JLabel msg = new  JLabel("My 2 Favorite Books are      ");
   JLabel msg1 = new  JLabel("1.)How to ged rid of being Human");
   JLabel msg2 = new JLabel("2.)Can I be a Superman?");
   Font headlineFont = new Font("Arial", Font.BOLD, 36);

   public JBookQuote()
   {
      super("My Favorite Book");      
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setLayout(flow);
      add(msg);
      msg.setFont(headlineFont);
      add(msg1); 
      add(msg2);

   }
    public static void main(String[] args)
   {
     JBookQuote aFrame = new JBookQuote();
     aFrame.setSize(600, 250);
     aFrame.setVisible(true);
   }


       
        
}