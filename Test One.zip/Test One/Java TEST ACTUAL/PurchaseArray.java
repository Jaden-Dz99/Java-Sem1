//Programmer:  Jaden Dzubiel.
//ID:          20027451
//Details:     Create a program which determines the tax added to the total sale amount with invoice

import java.util.Scanner; //Imports scanner
public class PurchaseArray
{
   public static void main(String[] args)
   {
      //Declares array for a total of six purchases made
	   Purchase[] purchase = new Purchase[6];
      //Invoice minimum is equal to 1001
	   final int INV_MINIMUM = 1001;
      //Invoice maximum is equal to 9999
	   final int INV_MAXIMUM = 9999;
      //The minimum sale price is equal to 0
	   final int SALE_MINIMUM = 0;
      //Set double and integers for variables
	   double saleAmount;
	   int invoiceN;
	   int z;
      //Creates the input scanner
	   Scanner input = new Scanner(System.in);
	
      //For loop which asks user to enter invoice number and sale amount for each of the six purchases
	   for (z = 0; z < 6; z++)
	   {
		   purchase[z] = new Purchase();
         //Asks user to enter invoice number
		   System.out.println("Please enter an Invoice Number between 1000 and 10`000 for purchase " + (z + 1));
		   invoiceN = input.nextInt();
		
         //Error message loop when invoice not in specified range
		   while (invoiceN < INV_MINIMUM || invoiceN > INV_MAXIMUM)
		   {
			   System.out.println("Invalid input - entry must be between 1000 and 10`000 ");
			   invoiceN = input.nextInt();
		   }
		
		   purchase[z].setInvoiceNumber(invoiceN);
		
		   System.out.println("Please enter a non-negative Sale Amount for purchase " + (z + 1));
		   saleAmount = input.nextDouble();
		   
         //Error message loop when sale amount is not a positive number
		   while(saleAmount < SALE_MINIMUM)
		   {
			   System.out.println("Invalid input - entry must be a positive number for purchase " + (z + 1));
			   saleAmount = input.nextDouble();
		   }
		   purchase[z].setSaleAmount(saleAmount);
	   }  
      //Displays purchases with corresponding invoice number and sale amount
	   for(z = 0; z < 6; z++)
	   {
		   purchase[z].display();
	   }
   }
}