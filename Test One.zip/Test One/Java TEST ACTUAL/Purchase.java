//Programmer:  Jaden Dzubiel.
//ID:          20027451
//Details:     Create a program which determines the tax added to the total sale amount with invoice

import java.text.DecimalFormat; //imports the decimal format
public class Purchase
{
   //Declare integer, doubles and format for decimal
	private int invoiceN; 
	private double saleAmount;
	private double saleTax = 1.07;
	private static DecimalFormat f = new DecimalFormat("#.##");
	
   //Retrieves invoice number from PurchaseArray class
	public void setInvoiceNumber(int setInvNum)
	{
		invoiceN = setInvNum;
	}
   //Retrieves sale amount from PurchaseArray class and multiplies it by sale tax
	public void setSaleAmount(double setSaleA)
	{
		saleAmount = setSaleA * saleTax;
	}
	//Returns invoice number
	public int getInvoiceNumber()
	{
		return invoiceN;
	}
   //Returns sale amount
 	public double getSaleAmount()
	{
		return saleAmount;
	}
   //Display method (for PurchaseArray) which outputs the get() method
	public void display()
	{
		System.out.println("Invoice Number is: " + getInvoiceNumber());
		System.out.println("Sale Amount: $" + f.format(getSaleAmount()) + "\n");
	}
}