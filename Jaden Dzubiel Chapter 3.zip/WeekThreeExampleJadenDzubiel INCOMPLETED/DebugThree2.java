public class DebugThree2
{
   public static void main(String args[])
   {
      int a = 2, b = 5, c = 10;
      addNum(a, b);
      subtractNum(c, a);            
   }
   public static int addNum(int a, int b)
   {
   int add = a + b;
      System.out.println("The sum of " + "a" +
         "and" + "b" + "is" + add);
         return add;
   }
   public static int subtractNum(int a, int c)
   {
      int subtract = c - a;
      System.out.println("The difference between " +
        "a" + "and" + "c" + "is" + subtract);
        return subtract;
   }
}