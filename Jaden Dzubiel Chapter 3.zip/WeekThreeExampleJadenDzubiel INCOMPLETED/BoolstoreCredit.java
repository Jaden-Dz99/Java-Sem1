import java.util.Scanner;

public class BoolstoreCredit 
{

   public static void main(String[] args)
   {
      Scanner input = new Scanner (System.in);
      String name;
      double  gpa;
      System.out.print ("Enter Your Name ==> ");
      name = input.nextLine();
      System.out.print("Enter Your GPA ==> ");
      gpa = input.nextDouble();
      displaycomputerCredit (name, gpa);    
    }
  
  public static void displaycomputerCredit(String name, double gpa)
  {
     System.out.println(name + " Your GPA Of " + gpa + 
     ",has earned your a bookstore credit of $" + (gpa * 10) );
     }
     
     
   }