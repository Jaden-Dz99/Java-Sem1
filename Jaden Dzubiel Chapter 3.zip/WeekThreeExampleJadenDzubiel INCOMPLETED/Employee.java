public class Employee 
{
   private int empNum;
   private String empLastName;
   private String empFirstName;
   private double empSalary;
   public int getEmpNum()
   {
      return empNum;
   }
   public void setEmpNum(int emp)
   {
      empNum = emp;
   }
   public String getEmpLastName()
   {
      return empLastName;
   }
}