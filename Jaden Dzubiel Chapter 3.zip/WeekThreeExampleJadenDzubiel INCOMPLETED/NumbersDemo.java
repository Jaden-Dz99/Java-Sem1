import java.util.Scanner;
public class NumbersDemo
{
   public static void main(String[] args)
   {
   
   int num1 = 10;
   int num2 = 26;

   displayTwiceTheNumber(num1);
   displayNumberPlusFive(num1);
   displayNumberSquared(num1);
   displayTwiceTheNumber(num2);
   displayNumberPlusFive(num2);
   displayNumberSquared(num2);
   
   }
   
   public static void displayTwiceTheNumber(int num)
   {
      System.out.println(num + " multiplied by two gives " + (num * 2));
   }
   
   public static void displayNumberPlusFive(int num)
   {
      System.out.println(num + " add five " + (num + 5));
   }
   
   public static void displayNumberSquared(int num)
   {
      System.out.println(num + " squared gives " + (num * num));
   }
}