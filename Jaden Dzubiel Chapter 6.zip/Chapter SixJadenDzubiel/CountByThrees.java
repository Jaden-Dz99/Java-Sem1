public class CountByThrees 
{
    public static void main(String[] args)
    {
        int begin ;
        int end = 300;

        for (begin = 3; begin<=end; begin = begin+3 )
        {
            System.out.println(begin + "");
            if (begin%30==0)
            {
                System.out.println();
            }
        }
    }
}
