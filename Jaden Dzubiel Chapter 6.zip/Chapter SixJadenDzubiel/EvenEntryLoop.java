import java.util.Scanner;

public class EvenEntryLoop 
{
    public static void main(String[] args) 
    {
        int sentinel = 999;

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter an even number or enter 999 to stop");

        int entry = scanner.nextInt();

        while (entry != sentinel)
            if (entry % 2 == 0) 
            {
                System.out.println("Good Job!");
                System.out.println("Enter another even number or enter 999 to stop");
                entry = scanner.nextInt();
            } 
            else if (entry % 2 == 1) 
            {
                System.out.println("Entry not an even number");
                System.out.println("Enter another even number or enter 999 to stop");
                entry = scanner.nextInt();
            }
            else
            {
                scanner.close();
            }
    }
}
