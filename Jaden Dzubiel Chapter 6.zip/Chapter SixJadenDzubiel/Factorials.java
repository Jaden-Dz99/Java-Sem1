public class Factorials {
    public static void main(String[] args)
    {
        int firstNum;
        int lastNum = 10;

        int result = 1;

        for (firstNum = 1; firstNum <= lastNum; firstNum++)
        {
            for (int count = firstNum; count > 0; count--)
            {
                result = result * count;

            }
            System.out.println("The Factorial of " + firstNum + " is " + result);
            result = 1;
        }
    }
}
