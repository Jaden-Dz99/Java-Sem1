import java.util.Scanner;

public class CountByAnything 
{
    public static void main(String[] args)
    {
        int begin ;
        int end = 300;
        int count = 0;

        Scanner scanner= new Scanner(System.in);

        System.out.println("Enter value to be counted by");

        int value= scanner.nextInt();

        for (begin = 3; begin<=end; begin = begin+value )
        {
            count++;

            System.out.println(begin + "");
            if (count%10==0)
            {
                System.out.println();
            }
        }
    }
}