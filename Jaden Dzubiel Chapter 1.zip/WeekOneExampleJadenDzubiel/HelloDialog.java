//Filename HelloDialog.java
//Written by Jaden
//Written on <21/02/2019>
import javax.swing.JOptionPane;
public class HelloDialog
{
   public static void main(String[] args)
   {
      JOptionPane.showMessageDialog(null, "Omae wa Mou Shindeiru, Nani?");
   }
}
