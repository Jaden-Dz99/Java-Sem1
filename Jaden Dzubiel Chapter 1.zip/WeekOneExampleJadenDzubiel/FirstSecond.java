public class First
{
   public static void main(String[] args)
   {
     System.out.println("First Java Application");
     System.out.println("Java Application");
   }
}