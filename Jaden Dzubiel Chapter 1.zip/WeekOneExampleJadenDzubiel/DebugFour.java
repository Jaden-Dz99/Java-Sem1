import javax.swing.JOptionPane;
public class DebugFour
{
  public static void main(String[] args)
  {
     JOptionPane.showMessageDialog(null, "First GUI program");
  }
}