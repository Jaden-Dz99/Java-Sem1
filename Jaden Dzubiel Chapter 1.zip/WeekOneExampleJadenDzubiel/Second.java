public class Second
{
public static void main(String[] args)
{
// Demonstrating comments
/* This shows
   that these comments
   don't matter */
System.out.println("Hello"); // This line executes
// up to where the comment started
/* Everything but the println() is a comment */
}
}
