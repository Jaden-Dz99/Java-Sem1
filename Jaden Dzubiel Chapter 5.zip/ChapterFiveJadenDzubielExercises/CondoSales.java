import java.util.Scanner;

public class CondoSales 
{
   public static void main(String[] args)
   {
      final int PARKVIEW = 150000;
      final int GOLFVIEW = 170000;
      final int LAKEVIEW = 210000;
      
      int choose;
      int price;
      
      Scanner scanner = new Scanner(System.in);
      
      System.out.println("Choose 1 for Park View");
      System.out.println("Choose 2 for Golf View");
      System.out.println("Choose 3 for Lake View");
      
      System.out.println("Enter either 1, 2 or 3");
      
      choose = scanner.nextInt();
      
      if (choose == 1)
      {
         price = PARKVIEW;
         System.out.println("A Park View condo is " + price);
      }
      else if (choose == 2)
      {
         price = GOLFVIEW;
         System.out.println("A Golf View condo is " + price);
      }
      else if (choose == 3)
      {
         price = LAKEVIEW;
         System.out.println("A Lake View condo is " + price);
      }
      else
      {
      price = 0;
      }
   }
}
      