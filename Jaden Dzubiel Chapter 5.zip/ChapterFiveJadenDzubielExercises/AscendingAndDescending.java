import java.util.Scanner;
public class AscendingAndDescending 
{
   public static void main(String[] args)
   {
      Scanner scanner = new Scanner(System.in);
      int a;
      int b;
      int c;
      
      System.out.println("Enter a: ");
      a=scanner.nextInt();
      System.out.println("Enter b: ");
      b=scanner.nextInt();
      System.out.println("Enter c: ");
      c=scanner.nextInt();
      
      if (a<=b && a<=c)
      {
         if(b<=c)
         {
            System.out.println("Ascending Order is: " + a + b + c);
            System.out.println("Descending Order is: " + c + b + a);
         }
         else
         {
            System.out.println("Ascending Order is: " + a + c + b);
            System.out.println("Ascending Order is: " + b + c + a);
         }
      }
      
      else if (b<=a && b<=c)
      {
         if(b<=c)
         {
            System.out.println("Ascending Order is: " + b + a + c);
            System.out.println("Descending Order is: " + c + a + b);
         }
         else
         {
            System.out.println("Ascending Order is: " + b + c + a);
            System.out.println("Ascending Order is: " + a + c + b);
         }
      }
      
         if(a<=b)
         {
            System.out.println("Ascending Order is: " + c + a + b);
            System.out.println("Descending Order is: " + b + a + c);
         }
         else
         {
            System.out.println("Ascending Order is: " + c + b + a);
            System.out.println("Ascending Order is: " + a + b + c);
         }
      }
   }       