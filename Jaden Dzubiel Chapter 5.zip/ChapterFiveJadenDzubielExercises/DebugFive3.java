import java.util.Scanner;
public class DebugFive3
{
   public static void main (String args[])
   {
      int item;
      String output = "";
      final int LOW = 111;
      final int HIGH = 999;
      final int CUTOFF = 500;
      Scanner input = new Scanner(System.in);
      System.out.println("Please enter item number");
      item = input.nextInt();
     
         if(item >= HIGH)
         output = "Item number is invalid";
      else
         if(item >= CUTOFF)
         output = "Valid - in Automotive Department";
      else
         if(item >= LOW)
         output = "Valid - in Housewares Department";
      else
         if(item < LOW)
         output = "Item number is invalid and too low";
         
         System.out.println(output);
   }
}


