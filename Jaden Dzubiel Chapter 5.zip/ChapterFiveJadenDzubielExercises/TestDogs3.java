public class TestDogs3
{
   public static void main(String[] args)
   {
      DogTriathlonParticipant3 dog1 =
        new DogTriathlonParticipant3("Bowser", 0, 0, 0, 0);
      dog1.display();
      DogTriathlonParticipant3 dog2 =
        new DogTriathlonParticipant3("Rush", 0, 90, 0, 0);
      dog2.display();DogTriathlonParticipant3 dog3 =
        new DogTriathlonParticipant3("Ginger", 1, 80, 80, 60);
      dog3.display();
      DogTriathlonParticipant3 dog4 =
        new DogTriathlonParticipant3("Misty", 1, 0, 10, 10);
      dog4.display();
      DogTriathlonParticipant3 dog5 =
        new DogTriathlonParticipant3("Molly", 1, 90, 0, 0);
      dog5.display();
      DogTriathlonParticipant3 dog6 =
        new DogTriathlonParticipant3("Murphy", 2, 80, 80, 60);
      dog6.display();
      DogTriathlonParticipant3 dog7 =
        new DogTriathlonParticipant3("Bingo", 2, 0, 0, 10);
      dog7.display();
      DogTriathlonParticipant3 dog8 =
        new DogTriathlonParticipant3("Duchess", 2, 90, 0, 100);
      dog8.display();
      DogTriathlonParticipant3 dog9 =
        new DogTriathlonParticipant3("Brutus", 3, 80, 80, 60);
      dog9.display();
      DogTriathlonParticipant3 dog10 =
        new DogTriathlonParticipant3("Sally", 3, 0, 0, 10);
      dog10.display();
      DogTriathlonParticipant3 dog11 =
        new DogTriathlonParticipant3("Rush", 3, 90, 0, 100);
      dog11.display();
      DogTriathlonParticipant3 dog12 =
        new DogTriathlonParticipant3("Lola", 4, 80, 80, 60);
      dog12.display();
   }
}
