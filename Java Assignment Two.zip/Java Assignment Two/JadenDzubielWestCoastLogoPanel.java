//Programmer: Jaden Dzubiel
//ID: 20027451
//Detail: Application to calculate product hire through various user inputs

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Color;
public class JadenDzubielWestCoastLogoPanel extends JPanel
{
   public void paintComponent(Graphics g)
   {
   //Script to display WestCoast Computers header
      super.paintComponent(g);
      g.setFont(new Font("Algerian", Font.ITALIC, 28));
      g.setColor(Color.PINK);
      g.fillOval(5, 5, 40, 40);
      g.setColor(Color.PINK);
      g.fillOval(15, 5, 40, 40);
      g.setColor(Color.PINK);
      g.fillOval(30, 5, 40, 40);
      g.setColor(Color.BLUE);
      g.drawString("WestCoast Computers", 50, 30);
   }
}