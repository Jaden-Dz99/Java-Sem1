//Programmer: Jaden Dzubiel
//ID: 20027451
//Detail: Application to calculate product hire through various user inputs

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Color;
public class JadenDzubielWestCoastComputerRentals extends JFrame implements ItemListener, ActionListener
{
   // Script to include checkboxes, form layout, variable declarations and fonts
   Container con = getContentPane();
   GridLayout mainGrid = new GridLayout(3, 1);
   GridLayout grid0 = new GridLayout(2, 1);
   GridLayout grid1 = new GridLayout(1, 2, 12, 12);
   GridLayout grid2 = new GridLayout(8, 1, 1, 1);
   JPanel introPanel = new JPanel();
   JPanel promptPanel = new JPanel();
   JPanel boxesPanel = new JPanel();
   JPanel OptionPanel = new JPanel();
   JPanel LessonPanel = new JPanel();
   JPanel endPanel = new JPanel();
   JadenDzubielWestCoastLogoPanel logoPanel = new JadenDzubielWestCoastLogoPanel();
   JPanel totalPanel = new JPanel();
   JTextField hoursField = new JTextField(8);
   JLabel hoursLabel = new JLabel("Please enter hours for rental");
   JCheckBox pcBox = new JCheckBox("PC Computer", false);
   JCheckBox macBox = new JCheckBox("MAC Computer", false);
   JCheckBox laptopBox = new JCheckBox("laptop", false);
   JCheckBox iPadBox = new JCheckBox("iPad", false);
   JCheckBox LaptopBox = new JCheckBox("Laptop", false);
   JCheckBox laserBox = new JCheckBox("Laser Printer", false);
   JCheckBox scannerBox = new JCheckBox("Scanner", false);
   JCheckBox Lesson = new  JCheckBox("Lesson", false);
   JCheckBox NoLesson = new  JCheckBox("No Lesson", false);
   JLabel mainLabel = new JLabel("                 West Coast Computer Rentals");
   Font font = new  Font("Arial",Font.ITALIC, 30);
   JLabel label2 = new JLabel("Total");
   JLabel label1 = new JLabel("Select options");
   JLabel totPrice = new JLabel();
   double price = 0;
   int uprice;
   double PRICE_PER_HOUR;
   String OptionString = "";
   String LessonString = "";
   String output;
   int numSelected = 0;
   public JadenDzubielWestCoastComputerRentals()
   {
   // Script to include options and layout of GUI regarding formatting etc.
      super("Menu options");
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      con.setLayout(mainGrid);
      ButtonGroup OptionGroup = new ButtonGroup();
      OptionGroup.add(pcBox);
      OptionGroup.add(macBox);
      OptionGroup.add(laptopBox);
      OptionGroup.add(iPadBox);
      OptionGroup.add(LaptopBox);
      OptionGroup.add(laserBox);
      OptionGroup.add(scannerBox);
      
      OptionPanel.add(pcBox);
      OptionPanel.add(macBox);
      OptionPanel.add(laptopBox);
      OptionPanel.add(iPadBox);
      OptionPanel.add(LaptopBox);
      OptionPanel.add(laserBox);
      OptionPanel.add(scannerBox);
      
      LessonPanel.add(Lesson);
      LessonPanel.add(NoLesson);
      introPanel.add(mainLabel);
      introPanel.add(promptPanel);
      promptPanel.add(hoursLabel);
      promptPanel.add(hoursField);
      con.add(introPanel);
      con.add(boxesPanel);
      boxesPanel.add(OptionPanel);
      boxesPanel.add(LessonPanel);
      introPanel.setLayout(grid0);
      boxesPanel.setLayout(grid1);
      OptionPanel.setLayout(grid2);
      LessonPanel.setLayout(grid2);
      
      promptPanel.setLayout(new FlowLayout());
      endPanel.setLayout(grid0);
      mainLabel.setFont(font);
      endPanel.add(logoPanel);
      logoPanel.setBackground(Color.PINK);
      endPanel.add(totalPanel);
      totalPanel.add(label2);
      totalPanel.add(totPrice);
      totPrice.setText("$0");
      con.add(endPanel);
      
      // Action event listeners
      hoursField.addActionListener(this);
      pcBox.addItemListener(this);
      macBox.addItemListener(this);
      laptopBox.addItemListener(this);
      iPadBox.addItemListener(this);
      LaptopBox.addItemListener(this);
      laserBox.addItemListener(this);
      scannerBox.addItemListener(this);
      Lesson.addItemListener(this);
      NoLesson.addItemListener(this);
      
      // Colour to be selected for each Panel of application
      introPanel.setBackground(Color.PINK);
      endPanel.setBackground(Color.PINK);
      logoPanel.setBackground(Color.PINK);
      totalPanel.setBackground(Color.PINK);
      promptPanel.setBackground(Color.PINK);
   }
   // User required to input amount of hours to rent product
   @Override
   public void actionPerformed(ActionEvent e)
   {
      Object source = e.getSource();
      if(source == hoursField)
      {
        try
        {
          price = Integer.parseInt(hoursField.getText()) * PRICE_PER_HOUR;   
        }
        catch(Exception exc)
        {
          price = 0;
        }
        output = "$" + price + " Option Chosen " + OptionString +
        LessonString;
        totPrice.setText(output);
      }
   }
   @Override
   // User is required to select product, depending on product the prices to hire will vary
   public void itemStateChanged(ItemEvent check)
   {
     Object source = check.getItem();
     int select = check.getStateChange();
     if(select == ItemEvent.SELECTED)
      
     if(source == pcBox || source == macBox)
      {
         price = Integer.parseInt(hoursField.getText()) * 30;
      }
      else if(source == laptopBox || source == iPadBox || source == LaptopBox)
      {
         price = Integer.parseInt(hoursField.getText()) * 20;
      }
      else if(source == laserBox || source == scannerBox)
      {
         price = Integer.parseInt(hoursField.getText()) * 7;
      }       
      
      // Selected product will indicate selection on final output
      if(source == macBox)
      {
      OptionString = "- MAC Computer -";
      }
      if(source == pcBox)
      {
      OptionString = "- PC Computer -";
      }
      if(source == laptopBox)
      {
      OptionString = "- laptop -";
      }
      if(source == LaptopBox)
      {
      OptionString = "- Laptop -";
      }
      if(source == iPadBox)
      {
      OptionString = "- iPad -";
      }
      if(source == laserBox)
      {
      OptionString = "- Laser Printer -";
      }
      if(source == scannerBox)
      {
      OptionString = "- Scanner -";
      }

      // User has the option to receive a lesson for an additional $5
      if(select == ItemEvent.SELECTED)
      {
         if(source == Lesson)
         {
 	         uprice = 5;
            NoLesson.setSelected(false);
             LessonString = "- Lesson -";
         }
         else if(source == NoLesson)
         {
            uprice = 0;
            Lesson.setSelected(false);
            LessonString = "- No Lesson -";
         }  
      }                    
      
      // Output is processed with a relevant summary of selected inputs   
      output = "$" + (price + uprice) + " Option Chosen: " + OptionString +
      LessonString;
      totPrice.setText(output);
   }     
   // Java frame size is set
   public static void main(String[] args)
   {
      JadenDzubielWestCoastComputerRentals frame = new JadenDzubielWestCoastComputerRentals();
      frame.setSize(650, 600);
      frame.setVisible(true);
   }
}