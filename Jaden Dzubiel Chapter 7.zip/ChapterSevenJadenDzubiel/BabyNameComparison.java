import java.util.Scanner;
public class BabyNameComparison 
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        String firstName;
        String secondName;
        String thirdName;

        System.out.println("Please enter first name");
        firstName = scanner.nextLine();

        System.out.println("Please enter second name");
        secondName = scanner.nextLine();

        System.out.println("Please enter third name");
        thirdName = scanner.nextLine();

        String combination1 = firstName.concat("" + secondName );
        String combination2 = firstName.concat("" + thirdName );
        String combination3 = secondName.concat("" + firstName );
        String combination4 = secondName.concat("" + thirdName );
        String combination5 = thirdName.concat("" + firstName );
        String combination6 = thirdName.concat("" + secondName );

        System.out.println(combination1);
        System.out.println(combination2);
        System.out.println(combination3);
        System.out.println(combination4);
        System.out.println(combination5);
        System.out.println(combination6);
    }
}
