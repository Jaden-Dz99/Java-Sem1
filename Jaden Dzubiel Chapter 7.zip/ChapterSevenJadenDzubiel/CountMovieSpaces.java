public class CountMovieSpaces {
    public static void main(String[] args)
    {
        String movieQuote = "Charlie Dont Surf";

        int space = 0;

        for (int count = 0; count < movieQuote.length(); count++ )
        {
            if (Character.isSpaceChar(movieQuote.charAt(count)))
            {
                space = space+1;

            }
        }
        System.out.println("Movie Quote " + movieQuote);
        System.out.println("Number of spaces in quote " + space);
    }
}
