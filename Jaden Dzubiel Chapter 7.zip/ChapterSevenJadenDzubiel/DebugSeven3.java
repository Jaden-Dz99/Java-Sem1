// Program displays some facts about a string
public class DebugSeven3
{
   public static void main(String[] args)
   { 
      String stringQuote = "Honesty is the first chapter in the book of wisdom. - Thomas Jefferson" ;

      System.out.println("index.of('f') is: " + stringQuote.indexOf('f'));
      System.out.println("index.of('x') is: " + stringQuote.indexOf('x'));
      System.out.println("char.At(5) is: " + stringQuote.charAt(5));
      System.out.println("endsWith(\"daughter\") is: " + stringQuote.endsWith("daughter"));
      System.out.println("endsWith(\"son\") is: " + stringQuote.endsWith("son"));
      System.out.println("replace('e', '*') is: " + stringQuote.replace('e', 'M'));
   }
}