import java.util.Scanner;
public class validatePassword 
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);

        String Password;

        boolean repeatPassword = true;
        boolean upperCaseValid = false;
        boolean lowerCaseValid = false;
        boolean digitValid = false;

        int uppercase = 0;
        int lowercase = 0;
        int digit = 0;

        while(repeatPassword)
        {
            System.out.println("Enter Password with atleast 2 uppercase letters, 2 lowercase letters and atleast 2 digits");
            Password = scanner.nextLine();

            for (int count = 0; count < Password.length(); count++)
            {
                char password = Password.charAt(count);
                if (Character.isUpperCase(password))
                {
                    uppercase++;

                }
                else if (Character.isLowerCase(password))
                {
                    lowercase++;
                }
                else if (Character.isDigit(password))
                {
                    digit++;
                }
                if (uppercase>=2)
                {
                    upperCaseValid = true;

                }
                if (lowercase>=2)
                {
                    lowerCaseValid = true;
                }
                if (digit>=2)
                {
                    digitValid = true;
                }
                if (upperCaseValid && lowerCaseValid  && digitValid)
                {
                    System.out.println("Password was valid");
                    repeatPassword = false;
                }
                else
                {
                    if (uppercase<2)
                    {
                        System.out.println("Less than 2 uppercase letters");
                    }
                    if (lowercase<2)
                    {
                        System.out.println("Less than 2 uppercase letters");
                    }
                    if (digit<2)
                    {
                        System.out.println("less than 2 digits");
                    }
                    
                    lowerCaseValid = false;
                    upperCaseValid = false;
                    digitValid = false;
                    lowercase = 0;
                    uppercase = 0;
                    digit = 0;
                }
            }
        }
    }
}
