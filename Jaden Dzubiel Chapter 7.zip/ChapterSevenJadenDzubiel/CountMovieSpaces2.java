import java.util.Scanner;
public class CountMovieSpaces2 
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);

        String movieQuote;

        int space = 0;

        System.out.println("Enter movie quote");

        movieQuote = scanner.nextLine();

        for (int count = 0; count < movieQuote.length(); count++ )
        {
            if (Character.isSpaceChar(movieQuote.charAt(count)))
            {
                space = space+1;

            }
        }
        System.out.println("Movie Quote " + movieQuote);
        System.out.println("Number of spaces in quote " + space);
    }
}