import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class JMovieFrame extends JFrame implements ActionListener
{ 
   JButton northButton = new JButton("Interstellar");
   JButton southButton = new JButton("Lucy");
   JButton eastButton = new JButton("The Man from Earth");
   JButton westButton = new JButton("The Shawshank Redemption");
   JButton centerButton = new JButton("The Lord of the Rings: The Two Towers");
   JLabel northLabel = new JLabel("     2014, Matthew McConaughey");
   JLabel southLabel = new JLabel("     2014, Scarlett Johansson");
   JLabel eastLabel = new JLabel("      2007, David Lee Smith");
   JLabel westLabel = new JLabel("      1994, Tim Robbins");
   JLabel centerLabel = new JLabel("    2002, Viggo Mortensen");
   
   public JMovieFrame()
   {
      setTitle("JMovieFrame");
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setLayout(new BorderLayout());
      add(westButton,"West");
      add(centerButton,"Center");
      add(eastButton,"East");
      add(northButton,"North");
      add(southButton,"South");
      
      eastButton.addActionListener(this);
      centerButton.addActionListener(this);
      westButton.addActionListener(this);
      northButton.addActionListener(this);
      southButton.addActionListener(this);
   }
   @Override
   public void actionPerformed(ActionEvent e)
   {
      Object source = e.getSource();
      if(source == northButton)
      {
          remove(northButton);
          add(northLabel, BorderLayout.NORTH);
      }
      else
         if(source == southButton)
         {
             remove(southButton);
             add(southLabel, BorderLayout.SOUTH);
         }
         else
             if(source == eastButton)
             {
                remove(eastButton);
                add(eastLabel, BorderLayout.EAST);
             }
             else
               if(source == westButton)
               {
                  remove(westButton);
                  add(westLabel, BorderLayout.WEST);
               }
               else
               {
                  remove(centerButton);
                  add(centerLabel, BorderLayout.CENTER);
                }
      invalidate();
      validate();
   }
   public static void main(String[] args)
   {
      JMovieFrame movieFrame = new JMovieFrame();
      movieFrame.setSize(650,300);
      movieFrame.setVisible(true);
   }
}