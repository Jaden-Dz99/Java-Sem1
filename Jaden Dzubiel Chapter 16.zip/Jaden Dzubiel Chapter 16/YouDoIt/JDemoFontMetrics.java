//demonstrate FontMetrics methods.
import javax.swing.*; 
import java.awt.*;
public class JDemoFontMetrics extends JPanel 
{ 
//movie quote line 
String movieQuote = new String("Go ahead, make my day");

//create a few fonts to use for demonstration purposes:
Font courierItalic = new Font("Courier New", Font.ITALIC, 16),
 timesPlain = new Font("Times New Roman", Font.PLAIN, 16), 
 scriptBold = new Font("Freestyle Script", Font.BOLD, 16);
 

 //define four integer variables that hold the four font measurements
  int ascent, descent, height, leading;
 //two integer variables to hold the horizontal and vertical positions for output:
 int x, y;
 
 
 @Override public void paintComponent(Graphics g)
  { 
   super.paintComponent(g); 
   x = 20; //gives x and y starting values,
   y = 30; 
   g.setFont(courierItalic); //sets the font to each of the declared fonts,
   displayMetrics(g); 
   g.setFont(timesPlain);
   displayMetrics(g);
    g.setFont(scriptBold); 
   displayMetrics(g);
    }
    
    //displayMetrics() method with a Graphics parameter passed from the paintComponent() method.
   
 public void displayMetrics(Graphics g)
  { 
   //Obtain values for the four font statistics fields.
   leading = g.getFontMetrics().getLeading(); 
   ascent = g.getFontMetrics().getAscent();
    descent = g.getFontMetrics().getDescent(); 
    height = g.getFontMetrics().getHeight();
    //string is drawn at the appropriate increased vertical distance based on the font�s height.
     g.drawString(movieQuote, x, y += height);
     g.drawString("Leading is " + leading, x, y += height); 
     g.drawString("Ascent is " + ascent, x, y += height); 
     g.drawString("Descent is " + descent, x, y += height); 
     g.drawString("Height is " + height, x, y += height); 
     //increase the vertical coordinate again so that double spacing will appear
     // between each font�s set of five statements.
     y += height * 2; 
     }
    
    
    
    public static void main(String[] args)
      {
         JFrame frame = new JFrame(); 
         frame.add(new JDemoFontMetrics());
         frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
         frame.setSize(300, 460); frame.setVisible(true);
        }
     }
