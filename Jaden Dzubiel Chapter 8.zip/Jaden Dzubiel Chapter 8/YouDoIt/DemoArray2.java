public class DemoArray2
{
   public static void main(String[] args)
   {
      double[] salaries = {6.25, 6.55, 10.25, 16.85};      
   }
}