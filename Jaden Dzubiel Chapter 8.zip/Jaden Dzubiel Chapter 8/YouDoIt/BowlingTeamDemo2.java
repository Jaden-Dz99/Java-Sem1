import java.util.*;
public class BowlingTeamDemo2
{
   public static void main(String[] args)
   {
      String object;
      final int NUM_OBJECTS = 6;
      BowlingTeam[] teams = new BowlingTeam[NUM_OBJECTS];     
      int x;
      int y;
      final int NUM_TEAM_MEMBERS = 4;
      Scanner input = new Scanner(System.in);
      double invoice, amountSale;
      final int MAXIMUM = 10000;
      final int MINIMUM = 1000;
      String regex = "[a-zA-Z]+"; //Declaring regex (used for invoice number)		

      
      
      for(y = 0; y < NUM_OBJECTS; ++y)
      {
         teams[y] = new BowlingTeam();
         System.out.print("Enter Purchase Object " + (y+1) + " >> ");
         object = input.nextLine();
         teams[y].setTeamName(object);
               
         for(x = 0; x < NUM_TEAM_MEMBERS; ++x)
         {
            System.out.print("Please enter an Invoice Number >> ");
            invoiceNumber = input.nextLine();
            teams[y].setMember(x, object);
               while((invoiceNumber > MAXIMUM) || (invoice < MINIMUM))
                  {
                     System.out.println("The invoice has to be between 1000 and 10`000");
                     System.out.println("Please re-enter your invoice number: ");
                     invoiceNumber = scan.nextDouble();      
                   }

            
            System.out.print("Please enter the Amount of Sale>> ");
            object = input.nextLine();
            teams[y].setMember(x, object);
         }
      }
      
      for(y = 0; y < NUM_OBJECTS; ++y)
      {   
         System.out.println("\nMembers of Purchase Object " + teams[y].getTeamName());
         for(x = 0; x < NUM_TEAM_MEMBERS; ++x)
            System.out.print(teams[y].getMember(x) + " ");
         System.out.println();
      }     
   }
}