import javax.swing.*;

public class CarCareChoice2

{

   public static void main(String[] args)

   {

      final int NUM_OF_ITEMS = 8;

      String[] validChoices = {"oil change", "tire rotation", "battery check", "brake inspection", "oil", "tire", "bat","bra"};

      double[] prices = {25, 22, 15, 5, 25, 22, 15, 5};

      String strOptions;

      String careChoice;

      double choicePrice = 0.0;

      boolean validChoice = false;

      strOptions = JOptionPane.showInputDialog(null, "Please enter one of the following care options: oil change, tire rotation, battery check, or brake inspection");

      careChoice = strOptions;

      for(int x = 0; x < NUM_OF_ITEMS; ++x)

      {

         if(careChoice.equals(validChoices[x]))

         {

             validChoice = true;

             choicePrice = prices[x];

         }

     }

     if(validChoice)

        JOptionPane.showMessageDialog(null, "The price of a " + careChoice + " is $" + choicePrice);

     else

        JOptionPane.showMessageDialog(null, "Sorry - invalid entry");



   }

}
