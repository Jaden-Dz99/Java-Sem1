//Constructor for each subclass requires only a title
//The lines field is set using a constant value.
public class Couplet extends Poem 
{
    public Couplet(String name) 
    {
        super(name,2);//A couplet has two lines,
    }
}