//Constructor for each subclass requires only a title
//The lines field is set using a constant value.
public class Limerick extends Poem
{
    public Limerick(String name) 
    {
        super(name,5);// a limerick has five lines,
    }
}