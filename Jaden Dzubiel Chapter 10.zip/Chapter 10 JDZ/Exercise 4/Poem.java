public class Poem 
{
   protected String name;
   protected int num;
   //contains fields for the name of the poem
   public Poem() {}
   // a constructor that requires values for both fields.
   public Poem(String name, int num) 
   {
      this.name = name;
      this.num = num;
   }
   //the number of lines.
   public void display() 
   {
      System.out.println("Poem name: " + name + ". Line number: " + num);
   }

   //get methods to retrieve field values.
   public String getName() 
   {
      return name;
   }

   public int getNum() 
   {
      return num;
   }
}
