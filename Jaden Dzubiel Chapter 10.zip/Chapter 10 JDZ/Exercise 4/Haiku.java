////Constructor for each subclass requires only a title
//The lines field is set using a constant value.
public class Haiku extends Poem
{
    public Haiku(String name) 
    {
        super(name,3);//a haiku has three lines.
    }
}