import javax.swing.*;
public class Horse //Create a class named Horse 
   {     
      //Declare Valueble 
      String name, color;
	   int birthYear;
	   public Horse(String nm, String clr, int by) //Create data fields for name , colour, and year of birth.
	{
		setName(nm);
		setColor(clr);
		setBirthYear(by);		
	}
   
   // Set methods for these fields.
	public void setName(String nm)
   {
		name=nm;
	}
	public void setColor(String clr)
   {
	   color=clr;
	}
	public void setBirthYear(int by)
   {
		birthYear=by;
	}
    // Get methods for these fields.
	public String getName()
   {
		return name;
	}
	public String getColor()
   {
		return color;
	}
	public int getBirthYear()
   {
		return birthYear;
	}
}