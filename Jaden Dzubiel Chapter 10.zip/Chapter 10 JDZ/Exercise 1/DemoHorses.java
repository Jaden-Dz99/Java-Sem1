import javax.swing.*; //Write an application that demonstrates using objects of each class.
class DemoHorses 
{
	public static void main(String[] args) 
   {
		String name, color;
		int birthYear, races;
		
		Horse regularHorse = new Horse("PAPA", "White", 1990);
		
		RaceHorse speedyHorse = new RaceHorse("Aragon", "Black", 2002, 9999);	
	}
}