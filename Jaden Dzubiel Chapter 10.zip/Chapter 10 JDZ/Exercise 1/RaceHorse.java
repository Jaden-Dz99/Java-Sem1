import javax.swing.*;
class RaceHorse extends Horse//create a subclass named RaceHorse
{
	int races;//Add additional field that holds the number of races in which the horse has competed
	public RaceHorse(String name, String color, int birthYear, int rcs)
   {
	   super(name, color, birthYear);
		races=rcs;
	}
   
	public int getRaces()//Add additional methods to get and set the new field.
   {
		return races;
	}
}