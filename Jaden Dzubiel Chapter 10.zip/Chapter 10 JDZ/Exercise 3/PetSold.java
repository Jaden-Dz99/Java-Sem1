public class PetSold extends ItemSold 
{
    Boolean vacc, neut, house;
   //descends from ItemSold and includes
   public PetSold(int invoiceNo, String description, Double price, Boolean vacc, Boolean neut, Boolean house) 
   {
   super(invoiceNo, description, price);
   this.vacc = vacc;
   this.neut = neut;
   this.house = house;
   }

   @Override
   public void display() 
   {
      super.display();
      System.out.println("Vaccination Status: " + vacc + ". Neutered Status: " + neut + ". Housebroked status: " + vacc);
   }
   //Three Boolean fields that indicate whether the pet has been vaccinated, neutered, and housebroken,
    public Boolean getVacc() 
    {
        return vacc;
    }
//Plus get and set methods for these fields.
    public Boolean getNeut() 
    {
        return neut;
    }

    public Boolean getHouse() 
    {
        return house;
    }

    public void setVacc(Boolean vacc) 
    {
        this.vacc = vacc;
    }

    public void setNeut(Boolean neut) 
    {
        this.neut = neut;
    }

    public void setHouse(Boolean house) 
    {
        this.house = house;
    }
}