// Create a child class named ScentedCandle 
public class ScentedCandle extends Candle //contains an additional data field named
{
	private String scent;	 

	public String getScent() 
   {
		return this.scent;
	}
	
	public void setScent(String scent) 
   {
		this.scent = scent;
	}
	
	@Override //In the child class, over-ride the parents setHeight()
	public void setHeight(double height) 
   {
		super.height = height;
		super.price = 3.00 * height; //method to set price of a scented candle object to $3 per inch.
	}
}
