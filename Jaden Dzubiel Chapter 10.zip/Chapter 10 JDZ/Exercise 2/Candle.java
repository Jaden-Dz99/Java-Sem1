public class Candle 
{
   //Data fields for colour, height, and price.
	private String color;
	protected double height;
	protected double price;
	
   //get methods for all three fields.
	public String getColor() 
   {
		return this.color;
	}
	
   //set methods for colour and height
	public void setColor (String color) 
   {
		this.color = color;
	}
	
	public double getHeight() 
   {
		return this.height;
	}
	
   //Determine price as $2 per inch of height
	public void setHeight(double height) 
   {
		this.height = height;
		this.price = 2.00 * height;
	}
	
	public double getPrice() 
   {
		return this.price;
	}
}
