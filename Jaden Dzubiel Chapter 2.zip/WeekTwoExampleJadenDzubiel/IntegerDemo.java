import java.util.Scanner;
public class IntegerDemoInteractive
{
   public static void main(String[] args)
   {
   int anInt; 
   byte aByte; 
   short aShort; 
   long aLong; 
   Scanner Input = new Sanner(Sytsem.in);
   System.out.println("The int is " + anInt);
   System.out.println("The byte is " + aByte);
   System.out.println("The short is " + aShort);
   System.out.println("The long is " + aLong);
   System.out.print("Please enter an integer >> ");
   anInt = input.nextInt();
   System.out.print("Please enter a byte integer >> ");
   anInt = input.nextByte();
   System.out.print("Please enter a short integer >> ");
   anInt = input.nextShort();
   System.out.print("Please enter a long integer >> ");
   anInt = input.nextLong();
   }
}