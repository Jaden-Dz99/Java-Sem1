import javax.swing.JOptionPane;
public class QuartsToGallons
{  
   public static void main(String[] args)
   {
   String quartsString;
   int FirstNumber;
   int Sum;
   int Remainder;
   
   quartsString = JOptionPane.showInputDialog("Please enter amount of Quarts needed >> " + JOptionPane.INFORMATION_MESSAGE);
   
  
   FirstNumber = Integer.parseInt(quartsString);
   
   Sum = FirstNumber / 4;
   Remainder = FirstNumber % 4;
   System.out.println("A job that needs " + FirstNumber + "quarts requires " + Sum + " gallons plus " 
   + Remainder + "quarts");
   }
}

