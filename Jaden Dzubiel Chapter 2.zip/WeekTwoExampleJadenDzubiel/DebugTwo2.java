public class DebugTwo2
//  This application performs arithmetic with two integers
{
   public static void main(String[] args)
   {
      int a = 7;
      int b = 4;
      int sum = a + b;
      int difference = a - b;
      int product = a * b;
      System.out.println("The sum is " + sum);
      System.out.println("The difference is " + difference);
      System.out.println("The product is " + product);
   }
}